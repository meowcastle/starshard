// THE TAKE PREVIEW REACH (17 Sep 2026): for every legal placement on real boards, resolve on a copy
// and diff ownership. Answers three things Design's direction sheet needs:
//   1. how far from the landing station does ownership actually change (can a neighbour-only mark tell the truth)
//   2. how often does placing a card LOSE you a station you already held (is the amber back-arrow reachable)
//   3. how many marks would be on screen in the half-strength "every legal station" state
// node preview.js <boards> <nights csv> [seedoff] [deck]
const E=require("/tmp/now2/v2.js");
const N=Number(process.argv[2]||224), NIGHTS=(process.argv[3]||"1").split(",").map(Number), SEEDOFF=Number(process.argv[4]||0), DECK=process.argv[5]||"fresh";
const {LAWS}=require("/tmp/now2/laws.js");
function rng(s){let h=(s^2166136261)>>>0;return()=>{h^=h<<13;h>>>=0;h^=h>>>17;h^=h<<5;h>>>=0;return h/4294967296;};}
function deal(r){const bag=Array.from({length:28},(_,i)=>i+1),o=[];while(o.length<7)o.push(bag.splice(Math.floor(r()*bag.length),1)[0]);return o;}
const SUN=14, PLANETS=[1,7,20,24,11];
function deck(){ const abOff={}, grants={}; if(DECK==="fresh") for(let i=1;i<=28;i++){ const L=i===SUN?3:PLANETS.includes(i)?2:1; if(L<2) abOff[i]=true; if(L>=3) grants[i]=true; }
  const C=E.makeCards({lvl:2, abOff, grants}); const o={}; for(let i=1;i<=28;i++){ o[i]={...C[i]}; o[200+i]={...C[i], id:200+i, who:"sky", homeM:i}; } return o; }

console.log(`THE TAKE PREVIEW REACH. ${DECK} deck, mirror board, both careful (8), ${N} boards a night, seed offset ${SEEDOFF}.`);
console.log("  night  options  chg>0%   d1only%  d2plus%  backTake%  halfMarks p50/p95/max  fullMarks p50/p95/max  chainNight");

for(const m of NIGHTS){
  const law=LAWS[m], tonight=((m-1-law.off+28)%28)+1, C=deck();
  let opts=0, changed=0, d1only=0, d2plus=0, backTake=0;
  const halfM=[], fullM=[];
  const r=rng(9090+SEEDOFF+m*31);
  for(let b=0;b<N;b++){
    const cfg=Object.assign({C, you:deal(r), sky:deal(r).map(x=>200+x), tonight, leader:(b%2?"sky":"you"),
      len:9, depth:8, youDepth:8, suzakuReach:true, suzakuBase:true, genbuDead:true, drawTo:"defender", dawn:"duel"}, law.cfg);
    const g0=E.mkGame(cfg);
    // walk the board forward with the real search, sampling the preview at each of OUR decision points
    let g={...g0}, guard=0;
    while(g.slots.some(x=>!x) && (g.you.length||g.sky.length) && guard++<40){
      const side=g.turn, hand=side==="you"?g.you:g.sky;
      const mv=hand.length? E.bestMove(g, side, 8) : null;
      if(!mv){ g.turn = side==="you"?"sky":"you"; continue; }
      if(side==="you" && !mv.suzakuTap && !mv.heartTap){
        const before=g.slots.map(x=>x?x.owner:null);
        const open=E.openSlots(g);
        const perCard={}, marksAtPointer=[];
        for(const id of hand) perCard[id]=0;
        for(const i of open){
          for(const id of hand){
            let anyHere=0;
            for(const rev of [false,true]){
              let rr; try{ rr=E.resolve({...g,real:false}, g.slots, id, i, rev, "you"); }catch(e){ continue; }
              opts++;
              let ch=0, far=0, back=0;
              rr.slots.forEach((x,k)=>{
                if(!x) return;
                const was=before[k];
                if(was===null) return;
                if(x.owner===was) return;
                ch++;
                if(Math.abs(k-i)>1) far++;
                if(was==="you") back++;
              });
              if(ch>0){ changed++; if(far>0) d2plus++; else d1only++; anyHere=1; }
              if(back>0) backTake++;
              marksAtPointer.push(ch);
            }
            perCard[id]+=anyHere;
          }
        }
        for(const id of hand) halfM.push(perCard[id]);
        if(marksAtPointer.length) fullM.push(Math.max(...marksAtPointer));
      }
      if(!mv.suzakuTap && !mv.heartTap){ const rr=E.resolve(g,g.slots,mv.id,mv.i,mv.rev,side); g.slots=rr.slots; }
      else g.slots=mv.r.slots;
      if(!mv.suzakuTap && !mv.heartTap){ if(side==="you") g.you=g.you.filter(x=>x!==mv.id); else g.sky=g.sky.filter(x=>x!==mv.id); }
      else if(mv.suzakuTap) g.taps["s"+mv.id]=true; else g.taps[mv.id]=true;
      g.turn = side==="you"?"sky":"you";
    }
  }
  const pct=(a,b)=>b? (100*a/b) : 0;
  const q=(A,p)=>{ if(!A.length) return 0; const s=[...A].sort((x,y)=>x-y); return s[Math.min(s.length-1, Math.floor(p*s.length))]; };
  console.log(`  m${String(m).padEnd(4)} ${String(opts).padStart(7)} ${pct(changed,opts).toFixed(1).padStart(7)} `+
    `${pct(d1only,opts).toFixed(1).padStart(8)} ${pct(d2plus,opts).toFixed(1).padStart(8)} ${pct(backTake,opts).toFixed(2).padStart(10)}  `+
    `${String(q(halfM,.5)).padStart(4)}/${String(q(halfM,.95)).padStart(3)}/${String(Math.max(0,...halfM)).padStart(3)}      `+
    `${String(q(fullM,.5)).padStart(4)}/${String(q(fullM,.95)).padStart(3)}/${String(Math.max(0,...fullM)).padStart(3)}`);
}
